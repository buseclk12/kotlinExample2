package com.example.busecelik_hw2.util

object Constants {
    const val TABLENAME="houses"
    const val DATABASENAME="houseDB"
}
